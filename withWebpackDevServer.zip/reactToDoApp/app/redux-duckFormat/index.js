import { combineReducers } from 'redux';
import todoModel from './todoModelReducer';

export default combineReducers ({
    todoModel
})